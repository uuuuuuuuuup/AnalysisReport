# .claude/skills/penetrate-financial-report/scripts/data_collector.py
"""Collect all required inputs for financial report."""
from typing import Dict, Any
import sys
import os

# Add narrative skill path to import shared data sources if needed
sys.path.insert(0, os.path.expanduser("~/.claude/skills/penetrate-narrative-stock-analysis/scripts"))
from data_sources import get_market_data_mx, get_market_data_lingxi, get_consensus_earnings
from data_sources import get_balance_sheet, get_income_statement, get_cash_flow_statement


def collect_financial_inputs(company_name: str, code: str) -> Dict[str, Any]:
    """Collect market data, earnings, and financial statements."""
    data = get_market_data_mx(company_name) or get_market_data_lingxi(company_name)
    if not data:
        raise RuntimeError(f"无法获取 {company_name} 的市场数据。")

    earnings = get_consensus_earnings(company_name) or {}

    inputs = {
        "company": company_name,
        "code": code,
        "market_cap": data["market_cap"],
        "price": data["price"],
        "total_shares": data.get("total_shares", data["market_cap"] / data["price"]),
        "e0": earnings.get("e0", 0),
        "e1": earnings.get("e1", 0),
        "e2": earnings.get("e2", 0),
        "e3": earnings.get("e3", 0),
        "balance_sheet": get_balance_sheet(code) or {},
        "income_statement": get_income_statement(code) or {},
        "cash_flow": get_cash_flow_statement(code) or {},
    }
    return inputs
